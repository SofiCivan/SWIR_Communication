﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApp1
{
    public class ControlTextWriter : TextWriter
    {
        private readonly TextBox _textBox;

        public ControlTextWriter(TextBox textBox)
        {
            _textBox = textBox;
        }

        public override Encoding Encoding => Encoding.UTF8;

        public override void Write(char value)
        {
            base.Write(value);
            _textBox.Dispatcher.Invoke(() => _textBox.AppendText(value.ToString()));
        }
    }
}
