﻿using SWIRTest;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            RedirectConsoleOutput();

            new RunSWIR().Run();
        }

        private void RedirectConsoleOutput()
        {
            var controlWriter = new ControlTextWriter(consoleOutputTextBox);
            Console.SetOut(controlWriter);
        }
    }
}