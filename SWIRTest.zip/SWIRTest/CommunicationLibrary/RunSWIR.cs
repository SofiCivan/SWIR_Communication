﻿using Civan.Devices.Shared.Infra;
using Devices.Cameras.Models.GenICam;
using System.Reflection;
using static Civan.Devices.Shared.Infra.IProCamera;
namespace SWIRTest;

public class RunSWIR
{

    public void Run()
    {
        try
        {
            IDevice dev;

            AppDomain currentDomain = AppDomain.CurrentDomain;

            //AppDomain.CurrentDomain.AssemblyLoad += OnAssemblyLoad;

            var dInfo = GenICam_Cam.GetDevices()[0];
            var parameters = new Dictionary<string, string>() { {"DeviceName", dInfo.Name },
                 {"DeviceID", dInfo.SerialNumber }
             };
            dev = new GenICam_Cam(parameters);

            Console.WriteLine($"running {dev.Name}...");
            try
            {
                dev.OpenDevice();
                RunDeviceTest(dev);
                dev.CloseDevice();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }

    }
    void RunDeviceTest(IDevice dev)
    {
        if (dev is IProCamera)
        {
            RunProCameraTest(dev);
        }
    }

    void RunIMotionControllerTest(IDevice dev)
    {
        IMotionController motor = dev as IMotionController;
        motor.MoveRelative(true, (1, 10));
    }

    void RunProCameraTest(IDevice dev)
    {
        IProCamera camera = (IProCamera)dev;


        camera.GetPixelSize(out double pixelSize);
        camera.GetMaxImageSize(out int[] maxImageSize);

        camera.AlocAndStartStream();

        camera.PauseStream();
        camera.ResumeStream();

        camera.GetCameraAvailable(out bool isAvailable);
        camera.GetTemperature(out double temperature);

        //test Exposure
        camera.GetExposureRange(out double minVal, out double maxVal, out double inc);
        camera.GetExposure(out double value);
        Console.WriteLine("Get Exposure result: " + value);
        camera.SetExposure(value);

        //test BitMode
        camera.GetBitMode(out BitMode bitMode);
        camera.SetBitMode(bitMode);

        //test AOI
        camera.GetAOIRangeParams(out int minWidth, out int maxWidth, out int incWidth,
                        out int minHeight, out int maxHeight, out int incHeight,
                        out int minPosX, out int maxPosX, out int incPosX,
                        out int minPosY, out int maxPosY, out int incPosY);
        camera.GetAOI(out int posX, out int posY, out int width, out int height);
        camera.SetAOI(posX, posY, width, height);

        //test Frame Rate
        camera.GetFrameRateRange(out double minFR, out double maxFR, out double incFR);
        camera.GetFrameRate(out double val);
        camera.SetFrameRate(val);

        Console.WriteLine($"Getting 10 frames...");

        for (int i = 0; i < 11; i++)
        {
            camera.GetImage(out byte[] image);
            Console.WriteLine($" image len {image.Length}");
            Thread.Sleep(100);
        }

        camera.StopStreamAndRelease();

    }

    private static void OnAssemblyLoad(object sender, AssemblyLoadEventArgs args)
    {
        Assembly loadedAssembly = args.LoadedAssembly;
        Console.WriteLine($"Loaded Assembly: {loadedAssembly.FullName}");
        Console.WriteLine($"Location: {loadedAssembly.Location}");

        // Optionally, list all referenced assemblies
        foreach (var reference in loadedAssembly.GetReferencedAssemblies())
        {
            Console.WriteLine($"Referenced Assembly: {reference.FullName}");
        }
    }

}
