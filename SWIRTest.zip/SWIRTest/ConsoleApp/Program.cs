﻿// See https://aka.ms/new-console-template for more information
using SWIRTest;

//using Devices.Cameras.Models.GenICam;

Console.WriteLine("Testing Connected Devices");

new RunSWIR().Run();