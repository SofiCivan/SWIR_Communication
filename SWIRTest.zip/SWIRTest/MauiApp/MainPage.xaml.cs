﻿using SWIRTest;
using MauiProgram;
using System.Collections.ObjectModel;

namespace MauiApp2
{
    public partial class MainPage : ContentPage
    {
        int count = 0;
        ObservableCollection<string> List = new();
        ControlTextWriter w;

        public MainPage()
        {
            InitializeComponent();
            RedirectConsoleOutput();
            ListV.ItemsSource = List;
            Task.Run(() => {
            new RunSWIR().Run();
            });

            Console.WriteLine("Hello\nworld");

        }


        private void RedirectConsoleOutput()
        {
            var controlWriter = new ControlTextWriter(ListV,List);
            Console.SetOut(controlWriter);
        }
    }

}
