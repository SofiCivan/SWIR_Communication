﻿using System.Collections.ObjectModel;
using System.Text;

namespace MauiProgram;

public class ControlTextWriter : TextWriter
{

    ObservableCollection<string> List;
    BindableObject _obj;
    public ControlTextWriter(BindableObject bindableObject ,  ObservableCollection<string> textBox)
    {
        List = textBox;
        _obj = bindableObject;
    }

    public override Encoding Encoding => Encoding.UTF8;

    string str = "";
    public override void Write(char value)
    {
        base.Write(value);
       str += value;
        if (value == '\n')
        {
            _obj.Dispatcher.DispatchAsync(() => {
                List.Add(str);
                str = "";

            });
        }

    }
}
